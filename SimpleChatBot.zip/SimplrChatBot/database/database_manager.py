from .database_connection import db

class DatabaseManager:
    """Manager class for database operations."""
    
    def __init__(self):
        self.db = db
    
    def save_conversation(self, user_message: str, bot_response: str):
        """Save a conversation to the database."""
        self.db.add_message(user_message, bot_response)
    
    def get_chat_history(self):
        """Get all chat history."""
        return self.db.get_all_messages()
    
    def clear_history(self):
        """Clear all chat history."""
        self.db.clear_messages()

# Global database manager instance
db_manager = DatabaseManager()