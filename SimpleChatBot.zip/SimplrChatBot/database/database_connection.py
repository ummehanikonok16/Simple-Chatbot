from typing import List, Dict
from datetime import datetime

class SimpleDatabase:
    """Simple in-memory database for storing chat messages."""
    
    def __init__(self):
        self.messages: List[Dict] = []
    
    def add_message(self, user_message: str, bot_response: str):
        """Add a conversation to the database."""
        self.messages.append({
            "user_message": user_message,
            "bot_response": bot_response,
            "timestamp": datetime.now().isoformat()
        })
    
    def get_all_messages(self) -> List[Dict]:
        """Get all stored messages."""
        return self.messages
    
    def clear_messages(self):
        """Clear all messages."""
        self.messages.clear()

# Global database instance
db = SimpleDatabase()