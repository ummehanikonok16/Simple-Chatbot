from fastapi import FastAPI
from fastapi.responses import HTMLResponse
import uvicorn
import os

# Import router
from services.feature_1.feature_1_router import router as chatbot_router

app = FastAPI(title="Groq Chatbot App")

# Include chatbot router
app.include_router(chatbot_router, prefix="/api")

@app.get("/", response_class=HTMLResponse)  
async def root():
    """Serve simple chat interface."""
    
    # Check if Groq API key is set
    api_key_status = "✅ Groq API configured" if os.getenv("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") else "⚠️ Using fallback mode - Set GROQ_API_KEY for full functionality"
    
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Groq Chatbot - Lightning Fast AI</title>
        <style>
            body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 40px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; }}
            .container {{ max-width: 800px; margin: 0 auto; background: white; border-radius: 20px; padding: 30px; box-shadow: 0 10px 30px rgba(0,0,0,0.2); }}
            .header {{ text-align: center; margin-bottom: 20px; }}
            .header h1 {{ color: #333; margin: 0; font-size: 2.5em; }}
            .header .subtitle {{ color: #666; margin: 10px 0; font-size: 1.1em; }}
            .status {{ background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 15px; border-radius: 12px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; }}
            .status-text {{ font-weight: 500; }}
            .test-btn {{ background: rgba(255,255,255,0.2); color: white; border: 1px solid rgba(255,255,255,0.3); padding: 8px 16px; border-radius: 20px; cursor: pointer; transition: all 0.3s; }}
            .test-btn:hover {{ background: rgba(255,255,255,0.3); }}
            .chat-box {{ height: 500px; border: 2px solid #e1e8ed; padding: 25px; overflow-y: scroll; margin-bottom: 25px; background: #fafbfc; border-radius: 15px; }}
            .message {{ margin: 18px 0; padding: 14px 18px; border-radius: 20px; max-width: 85%; line-height: 1.5; animation: fadeIn 0.3s ease-in; }}
            .user-message {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; margin-left: auto; text-align: right; }}
            .bot-message {{ background: #f8f9fa; color: #333; border: 1px solid #e1e8ed; }}
            .input-group {{ display: flex; gap: 15px; align-items: center; }}
            .input-group input {{ flex: 1; padding: 18px; border: 2px solid #e1e8ed; border-radius: 30px; outline: none; font-size: 16px; transition: border-color 0.3s; }}
            .input-group input:focus {{ border-color: #667eea; }}
            .input-group button {{ padding: 18px 35px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 30px; cursor: pointer; font-weight: 600; transition: all 0.3s; }}
            .input-group button:hover {{ transform: translateY(-2px); box-shadow: 0 8px 20px rgba(102, 126, 234, 0.4); }}
            .loading {{ color: #666; font-style: italic; }}
            .features {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 20px; }}
            .feature {{ background: #f8f9fa; padding: 15px; border-radius: 10px; text-align: center; border: 1px solid #e1e8ed; }}
            .feature .icon {{ font-size: 2em; margin-bottom: 10px; }}
            .feature .title {{ font-weight: 600; color: #333; margin-bottom: 5px; }}
            .feature .desc {{ color: #666; font-size: 0.9em; }}
            @keyframes fadeIn {{ from {{ opacity: 0; transform: translateY(10px); }} to {{ opacity: 1; transform: translateY(0); }} }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>⚡ Groq Chatbot</h1>
                <div class="subtitle">Lightning-fast AI responses powered by Groq</div>
            </div>
            
            <div class="status">
                <div class="status-text">Status: {api_key_status}</div>
                <button class="test-btn" onclick="testBot()">Test Connection</button>
            </div>
            
            <div class="features">
                <div class="feature">
                    <div class="icon">⚡</div>
                    <div class="title">Ultra Fast</div>
                    <div class="desc">Responses in milliseconds</div>
                </div>
                <div class="feature">
                    <div class="icon">🧠</div>
                    <div class="title">Smart Models</div>
                    <div class="desc">Llama 3, Mixtral & more</div>
                </div>
                <div class="feature">
                    <div class="icon">🆓</div>
                    <div class="title">Free Tier</div>
                    <div class="desc">Generous usage limits</div>
                </div>
                <div class="feature">
                    <div class="icon">💬</div>
                    <div class="title">Unlimited Topics</div>
                    <div class="desc">Ask about anything</div>
                </div>
            </div>
            
            <div id="chatBox" class="chat-box">
                <div class="message bot-message">
                    🚀 Hello! I'm powered by Groq's lightning-fast AI inference. I can help you with:
                    <br><br>
                    • <strong>Programming & Development</strong> - Code examples, debugging, best practices
                    <br>• <strong>Science & Technology</strong> - Explanations, concepts, latest trends  
                    <br>• <strong>Mathematics</strong> - Problem solving, explanations, calculations
                    <br>• <strong>Writing & Content</strong> - Essays, creative writing, editing
                    <br>• <strong>General Knowledge</strong> - Facts, history, current topics
                    <br><br>
                    What would you like to explore today? ⚡
                </div>
            </div>
            <div class="input-group">
                <input type="text" id="messageInput" placeholder="Ask me anything... (e.g., 'Explain quantum computing')" onkeypress="if(event.key==='Enter') sendMessage()">
                <button onclick="sendMessage()">Send ⚡</button>
            </div>
        </div>

        <script>
            async function sendMessage() {{
                const input = document.getElementById('messageInput');
                const message = input.value.trim();
                if (!message) return;

                const chatBox = document.getElementById('chatBox');
                
                // Add user message
                chatBox.innerHTML += `<div class="message user-message">${{message}}</div>`;
                input.value = '';
                
                // Add loading indicator
                chatBox.innerHTML += `<div class="message bot-message loading">⚡ Generating response...</div>`;
                chatBox.scrollTop = chatBox.scrollHeight;

                try {{
                    console.log('Sending message to Groq:', message);
                    
                    const startTime = Date.now();
                    const response = await fetch('/api/chat', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{ message: message }})
                    }});
                    const endTime = Date.now();
                    
                    const data = await response.json();
                    
                    // Remove loading indicator
                    const loadingMessages = chatBox.querySelectorAll('.loading');
                    loadingMessages.forEach(msg => msg.remove());
                    
                    // Add bot response with timing info
                    const responseTime = endTime - startTime;
                    chatBox.innerHTML += `<div class="message bot-message">${{data.response}}<br><small style="color: #999; font-size: 0.8em;">⚡ Groq response time: ${{responseTime}}ms</small></div>`;
                    
                    console.log('Groq response received in', responseTime, 'ms');
                }} catch (error) {{
                    console.error('Error:', error);
                    
                    // Remove loading indicator
                    const loadingMessages = chatBox.querySelectorAll('.loading');
                    loadingMessages.forEach(msg => msg.remove());
                    
                    chatBox.innerHTML += `<div class="message bot-message">❌ Sorry, I encountered an error. Please try again.</div>`;
                }}
                
                chatBox.scrollTop = chatBox.scrollHeight;
            }}
            
            async function testBot() {{
                try {{
                    const response = await fetch('/api/test');
                    const data = await response.json();
                    
                    let message = `🧪 Groq Test Results:\\n\\n`;
                    message += `Status: ${{data.chatbot_status}}\\n`;
                    message += `Groq Connection: ${{data.groq_connection?.status}}\\n`;
                    message += `Model: ${{data.model_info?.model}}\\n`;
                    message += `Test Response: ${{data.test_response?.substring(0, 100)}}...`;
                    
                    alert(message);
                }} catch (error) {{
                    alert('Test failed: ' + error.message);
                }}
            }}
            
            // Focus on input when page loads
            document.getElementById('messageInput').focus();
            
            // Example prompts on placeholder click
            const examples = [
                "Explain machine learning in simple terms",
                "Write a Python function to sort a list", 
                "What are the benefits of renewable energy?",
                "How does quantum computing work?",
                "Create a simple HTML webpage structure"
            ];
            
            let exampleIndex = 0;
            setInterval(() => {{
                const input = document.getElementById('messageInput');
                if (input === document.activeElement) return; // Don't change if user is typing
                
                input.placeholder = `Ask me anything... (e.g., '${{examples[exampleIndex]}}')`;
                exampleIndex = (exampleIndex + 1) % examples.length;
            }}, 3000);
        </script>
    </body>
    </html>
    """
    return HTMLResponse(content=html_content)

@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "provider": "Groq",
        "groq_configured": bool(os.getenv("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")),
        "timestamp": "2025-06-03"
    }

if __name__ == "__main__":
    print("🚀 Starting Groq Chatbot...")
    print("⚡ Powered by Groq - Lightning Fast AI")
    
    if os.getenv("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"):
        print("✅ Groq API key found")
    else:
        print("⚠️  Groq API key not found - using fallback mode")
        print("💡 To enable full AI features:")
        print("   1. Get API key from https://console.groq.com")
        print("   2. Set environment variable: GROQ_API_KEY=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")
    
    uvicorn.run(app, host="0.0.0.0", port=8001)