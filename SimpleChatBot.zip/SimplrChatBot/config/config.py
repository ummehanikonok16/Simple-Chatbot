import os

class Config:
    """Configuration class with Groq integration."""
    
    # App settings
    APP_NAME = "Groq Chatbot"
    APP_VERSION = "1.0.0"
    
    # Server settings
    HOST = "0.0.0.0"
    PORT = 8000
    
    # Groq settings - DIRECT API KEY (for testing)
    # Replace this with your actual API key
    GROQ_API_KEY = "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"
    
    # Fallback to environment variable if direct key not set
    if not GROQ_API_KEY:
        GROQ_API_KEY = os.getenv("GROQ_API_KEY")
    
    GROQ_MODEL = "llama3-70b-8192"
    MAX_TOKENS = 1000
    TEMPERATURE = 0.7
    
    # Chatbot settings
    MAX_MESSAGE_LENGTH = 1000
    BOT_NAME = "Groq ChatBot"
    
    # System prompt for the AI
    SYSTEM_PROMPT = """You are a helpful, accurate, and knowledgeable AI assistant. 
    Provide detailed, factual, and comprehensive answers to user questions. 
    If you're unsure about something, acknowledge it. 
    Be conversational but informative. 
    Format your responses clearly with examples when helpful."""