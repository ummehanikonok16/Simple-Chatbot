from groq import Groq
from datetime import datetime
from typing import List, Dict
import os
from database.database_manager import db_manager
from config.config import Config

class GroqChatBot:
    """Fixed Groq chatbot that actually calls the API properly."""
    
    def __init__(self):
        # Get API key from config
        self.api_key = Config.GROQ_API_KEY
        
        print(f"🔍 API Key from config: {self.api_key[:8] if self.api_key else 'None'}...")
        
        if not self.api_key:
            print("❌ GROQ_API_KEY not found in config!")
            self.use_groq = False
            self.client = None
        else:
            try:
                # Initialize Groq client
                self.client = Groq(api_key=self.api_key)
                self.use_groq = True
                print(f"✅ Groq API initialized successfully with key: {self.api_key[:8]}...")
                
                # Test the connection immediately
                test_response = self._test_connection()
                if test_response:
                    print("✅ Groq connection test successful!")
                else:
                    print("❌ Groq connection test failed!")
                    self.use_groq = False
                    
            except Exception as e:
                print(f"❌ Groq initialization failed: {e}")
                self.use_groq = False
                self.client = None
        
        # Configuration
        self.model = Config.GROQ_MODEL
        self.max_tokens = Config.MAX_TOKENS
        self.temperature = Config.TEMPERATURE
        self.system_prompt = Config.SYSTEM_PROMPT
    
    def _test_connection(self) -> bool:
        """Test if Groq API is working."""
        try:
            if not self.client:
                return False
                
            print("🧪 Testing Groq connection...")
            response = self.client.chat.completions.create(
                model="llama3-8b-8192",  # Fast model for testing
                messages=[{"role": "user", "content": "Say 'Connection test successful'"}],
                max_tokens=10
            )
            result = response.choices[0].message.content.strip()
            print(f"✅ Test response: {result}")
            return True
        except Exception as e:
            print(f"❌ Groq connection test failed: {e}")
            return False
    
    def get_groq_response(self, user_message: str) -> str:
        """Get actual response from Groq API."""
        if not self.use_groq or not self.client:
            return "❌ Groq API not available. Check your API key in config.py"
        
        try:
            print(f"🚀 Calling Groq API with message: {user_message[:50]}...")
            
            # Call Groq API directly
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system", 
                        "content": self.system_prompt
                    },
                    {
                        "role": "user", 
                        "content": user_message
                    }
                ],
                max_tokens=self.max_tokens,
                temperature=self.temperature
            )
            
            # Extract the response
            ai_response = response.choices[0].message.content.strip()
            print(f"✅ Groq responded with: {ai_response[:100]}...")
            return ai_response
            
        except Exception as e:
            error_msg = str(e)
            print(f"❌ Groq API error: {error_msg}")
            
            if "authentication" in error_msg.lower():
                return "❌ Authentication error: Please check your Groq API key in config.py"
            elif "rate limit" in error_msg.lower():
                return "⏳ Rate limit reached. Please try again in a moment."
            else:
                return f"❌ Groq API error: {error_msg}"
    
    def get_response(self, user_message: str) -> str:
        """Main method to get chatbot response."""
        if not user_message.strip():
            return "Please provide a message for me to respond to."
        
        print(f"📝 Processing user message: {user_message}")
        
        # Always try Groq API first (no fallbacks)
        if self.use_groq:
            bot_response = self.get_groq_response(user_message)
        else:
            bot_response = "❌ Groq API not configured. Please check your API key in config/config.py"
        
        # Save to database
        try:
            db_manager.save_conversation(user_message, bot_response)
            print("💾 Conversation saved to database")
        except Exception as e:
            print(f"⚠️  Database save error: {e}")
        
        return bot_response
    
    def test_groq_connection(self) -> Dict[str, str]:
        """Test Groq API connection with detailed info."""
        if not self.api_key:
            return {
                "status": "no_api_key",
                "message": "GROQ_API_KEY not found in config"
            }
        
        if not self.use_groq or not self.client:
            return {
                "status": "client_error", 
                "message": "Groq client not initialized properly"
            }
        
        try:
            print("🧪 Testing Groq connection...")
            response = self.client.chat.completions.create(
                model="llama3-8b-8192",
                messages=[{"role": "user", "content": "Respond with: Connection test successful"}],
                max_tokens=20
            )
            
            result = response.choices[0].message.content.strip()
            return {
                "status": "success",
                "message": "Groq API working perfectly",
                "test_response": result,
                "model": "llama3-8b-8192"
            }
            
        except Exception as e:
            return {
                "status": "error",
                "message": f"Groq API test failed: {str(e)}"
            }
    
    def get_model_info(self) -> Dict[str, str]:
        """Get current model configuration."""
        return {
            "groq_enabled": str(self.use_groq),
            "api_key_set": str(bool(self.api_key)),
            "current_model": self.model,
            "temperature": str(self.temperature),
            "max_tokens": str(self.max_tokens)
        }
    
    def get_chat_history(self):
        """Get chat history from database."""
        return db_manager.get_chat_history()
    
    def clear_history(self):
        """Clear chat history."""
        db_manager.clear_history()

# Global chatbot instance
chatbot = GroqChatBot()