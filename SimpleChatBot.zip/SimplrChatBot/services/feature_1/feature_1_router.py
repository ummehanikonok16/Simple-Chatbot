from fastapi import APIRouter, HTTPException
from typing import List, Dict
from datetime import datetime

from .feature_1_schema import ChatMessage, ChatResponse, ChatHistory
from .feature_1 import chatbot

router = APIRouter(tags=["groq-chatbot"])

@router.post("/chat", response_model=ChatResponse)
async def chat(message: ChatMessage):
    """Send a message to the Groq chatbot and get a response."""
    try:
        if not message.message.strip():
            raise HTTPException(status_code=400, detail="Message cannot be empty")
        
        print(f"🌐 API received message: {message.message}")
        
        # Get response from chatbot
        bot_response = chatbot.get_response(message.message)
        
        print(f"📤 API sending response: {bot_response[:100]}...")
        
        return ChatResponse(
            response=bot_response,
            timestamp=datetime.now().isoformat()
        )
    
    except Exception as e:
        print(f"❌ API Error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")

@router.get("/test")
async def test_chatbot():
    """Test the Groq chatbot functionality."""
    try:
        # Test Groq connection
        connection_test = chatbot.test_groq_connection()
        
        # Test basic response
        test_message = "Hello, this is a test message"
        test_response = chatbot.get_response(test_message)
        
        # Get model info
        model_info = chatbot.get_model_info()
        
        return {
            "chatbot_status": "working",
            "groq_connection": connection_test,
            "model_info": model_info,
            "test_message": test_message,
            "test_response": test_response,
            "timestamp": datetime.now().isoformat()
        }
    
    except Exception as e:
        return {
            "chatbot_status": "error",
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }

@router.get("/history", response_model=List[ChatHistory])
async def get_history():
    """Get chat history."""
    try:
        history = chatbot.get_chat_history()
        return [
            ChatHistory(
                user_message=msg["user_message"],
                bot_response=msg["bot_response"],
                timestamp=msg["timestamp"]
            )
            for msg in history
        ]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error getting history: {str(e)}")

@router.delete("/history")
async def clear_history():
    """Clear chat history and conversation context."""
    try:
        chatbot.clear_history()
        return {"message": "Chat history and conversation context cleared successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error clearing history: {str(e)}")

@router.get("/status")
async def get_status():
    """Get detailed chatbot status and configuration."""
    try:
        connection_test = chatbot.test_groq_connection()
        model_info = chatbot.get_model_info()
        
        return {
            "status": "active",
            "bot_name": "Groq ChatBot",
            "groq_enabled": chatbot.use_groq,
            "groq_connection": connection_test,
            "current_model": model_info["model"],
            "model_description": model_info["model_description"],
            "temperature": model_info["temperature"],
            "max_tokens": model_info["max_tokens"],
            "conversation_length": model_info["conversation_length"],
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }

@router.get("/models")
async def list_available_models():
    """List available Groq models."""
    try:
        models = chatbot.get_available_models()
        return {
            "available_models": [
                {
                    "name": name,
                    "description": description,
                    "current": name == chatbot.model
                }
                for name, description in models.items()
            ],
            "current_model": chatbot.model
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error getting models: {str(e)}")

@router.post("/settings/model")
async def change_model(model_name: str):
    """Change the Groq model."""
    try:
        available_models = chatbot.get_available_models()
        if model_name not in available_models:
            raise HTTPException(
                status_code=400, 
                detail=f"Invalid model. Choose from: {', '.join(available_models.keys())}"
            )
        
        chatbot.set_model(model_name)
        return {
            "message": f"Model changed to {model_name}",
            "description": available_models[model_name]
        }
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error changing model: {str(e)}")

@router.post("/settings/temperature")
async def change_temperature(temperature: float):
    """Change response creativity (0.0 = deterministic, 1.0 = very creative)"""
    try:
        if not 0.0 <= temperature <= 1.0:
            raise HTTPException(
                status_code=400,
                detail="Temperature must be between 0.0 and 1.0"
            )
        
        chatbot.set_temperature(temperature)
        return {"message": f"Temperature set to {temperature}"}
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error changing temperature: {str(e)}")

@router.get("/performance")
async def get_performance_info():
    """Get Groq performance information."""
    return {
        "provider": "Groq",
        "benefits": [
            "⚡ Ultra-fast inference speed",
            "🆓 Generous free tier",
            "🧠 Multiple powerful models",
            "💰 Cost-effective pricing",
            "🔄 Real-time responses"
        ],
        "models": {
            "llama3-70b-8192": "Best for complex reasoning and detailed answers",
            "llama3-8b-8192": "Fastest for quick responses",
            "mixtral-8x7b-32768": "Great for coding and technical questions",
            "gemma-7b-it": "Optimized for following instructions"
        },
        "current_model": chatbot.model
    }