from pydantic import BaseModel
from typing import Optional

class ChatMessage(BaseModel):
    """Schema for incoming chat messages."""
    message: str

class ChatResponse(BaseModel):
    """Schema for chatbot responses."""
    response: str
    timestamp: Optional[str] = None

class ChatHistory(BaseModel):
    """Schema for chat history."""
    user_message: str
    bot_response: str
    timestamp: str